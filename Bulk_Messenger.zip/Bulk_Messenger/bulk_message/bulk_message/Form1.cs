﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace bulk_message
{
    public partial class Form1 : Form
    {
        string[] proxy_arr;
        Thread newThread = null;
        string[] first_name_list, last_name_list, domain_list, mail_servers;
        public Form1() {
            InitializeComponent();
            string path = "004PROXY.txt";
            string[] lines = System.IO.File.ReadAllLines(path);
            proxy_arr = lines;
            first_name_list = System.IO.File.ReadAllLines("001SFIRST_NAME.txt");
            last_name_list = System.IO.File.ReadAllLines("002SLAST_NAME.txt");
            domain_list = System.IO.File.ReadAllLines("003SDOMAIN.txt");
            string[] mail_list_lines = System.IO.File.ReadAllLines("005MAIL_SERVER.txt");
            mail_servers = mail_list_lines;

            for (int i = 0; i < mail_list_lines.Length; i++)
            {
                this.server_list.Items.Add(mail_list_lines[i]);
            }

            for (int j = 0; j < lines.Length; j++) {
                this.proxy_list.Items.Add(lines[j]);
            }
        }

        private static Random random = new Random();
        public string RandomFirstNameString() {            
            return first_name_list[random.Next(first_name_list.Length)];
        }
        public string RandomLastNameString() {
            return last_name_list[random.Next(last_name_list.Length)];
        }
        public string RandomDomainString() {
            return domain_list[random.Next(domain_list.Length)];
        }
        private void Send_btn_Click(object sender, EventArgs e) {
            newThread = new Thread(this.DoSend);
            newThread.Start();
        }
        
        public void DoSend() {
            string path = "emails";
            string[] files = Directory.GetFiles(path, "*", SearchOption.AllDirectories);
            int limit_count = 30;
            Random random = new Random();
            int proxy_index = 0;
            int mail_server_index = 0;

            for (int i = 0; i < files.Length; i++) {                
                string address = string.Format("{0}{1}@{2}.com", RandomFirstNameString(), RandomLastNameString(), RandomDomainString());
                from_mail.Text = address;
                
                string[] lines = System.IO.File.ReadAllLines(files[i]);
                List<string> to_emails = new List<string>();                
                for(int j= 0; j< lines.Length; j++) {
                    this.listBox1.Items.Add(lines[j]);
                    to_emails.Add(lines[j]);
                    if ((j+1) % limit_count == 0) {
                        Thread.Sleep(1000);

                        String post_data = "";
                        String sender_mail = "\"from_email\": \"" + address + "\"";
                        String subject_name = "\"subject\": \"" + subject.Text + "\"";
                        String mail_template = "\"mail_content\": \"" + mail_content.Text + "\"";
                        String proxy_data = "\"proxy_list\": \"";
                        String mail_server_data = "\"mail_server\": \"";

                        proxy_data += proxy_arr[proxy_index];                        
                        proxy_data += "\"";                        
                        if (proxy_index == proxy_arr.Length - 1) {
                            proxy_index = 0;
                        } else {
                            proxy_index++;
                        }
                        mail_server_data += mail_servers[mail_server_index];
                        mail_server_data += "\"";
                        if (mail_server_index == mail_servers.Length - 1) {
                            mail_server_index = 0;
                        } else {
                            mail_server_index++;
                        }
                        String reciever_data = "\"to_emails\": [";
                        for (int k = 0; k < to_emails.Count; k++)
                        {
                            if (k == to_emails.Count- 1)
                                reciever_data += "\"" + to_emails[k]+"\"";
                            else
                                reciever_data += "\"" + to_emails[k] + "\",";
                        }
                        reciever_data += "]";
                        post_data = post_data + "{";
                        post_data += sender_mail;
                        post_data += ",";
                        post_data += subject_name;
                        post_data += ",";
                        post_data += mail_template;
                        post_data += ",";
                        post_data += proxy_data;
                        post_data += ",";
                        post_data += mail_server_data;
                        post_data = post_data + ",";
                        post_data += reciever_data;
                        post_data = post_data + "}";                        

                        MessageBox.Show(post_data);
                        send_request(post_data);
                        this.listBox1.Items.Clear();
                        to_emails.Clear();
                    }
                }                        
            }               
        }
        public void send_request(String post_data) {
            var request = (HttpWebRequest)WebRequest.Create("http://localhost:5001");
            var data = Encoding.ASCII.GetBytes(post_data);

            request.Method = "POST";
            request.ContentType = "text/json";
            request.ContentLength = data.Length;       

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, post_data.Length);
            }
            try
            {
                var response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                newThread.Abort();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            if (newThread != null)
                newThread.Abort();
        }
    }
}

